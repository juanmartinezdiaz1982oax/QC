﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestQC.Models;

namespace TestQC.Business
{
    public class ListaProductos
    {
        private static ListaProductos instance = null;
        public List<Producto> lstProductos = new List<Producto> { };
        public ListaProductos()
        {

        }
        public static ListaProductos Instance
        {
            get 
            {
                if (instance == null)
                {
                    instance = new ListaProductos();
                }
                
                return instance;
            }
        }

        public void Agregar(Producto producto)
        {
            int idProducto = lstProductos.Count() > 0 ? lstProductos.Max(pi => pi.Id) : 0;
            producto.Id = idProducto + 1;
            lstProductos.Add(producto);
        }

        public void Actualiza(Producto producto)
        {
            var objProducto = lstProductos.Where(pl => pl.Id == producto.Id).FirstOrDefault();
            if (objProducto != null)
            {
                lstProductos.RemoveAll(lp => lp.Id == producto.Id);
                lstProductos.Add(producto);
            }
        }

        public void Elimina(int id)
        {
            lstProductos.RemoveAll(lp => lp.Id == id);
        }

        public List<Producto> Listar()
        {
            return lstProductos.OrderBy(pl => pl.Id).ToList();
        }

        public Producto ObtienePorId(int id)
        {
            return lstProductos.Where(pl => pl.Id == id).FirstOrDefault();
        }

    }
}
