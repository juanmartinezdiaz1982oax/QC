﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TestQC.Business;
using TestQC.Datos;
using TestQC.Models;

namespace TestQC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ProductoOperacion productoOperacion;

        public HomeController()
        {
            productoOperacion = new ProductoOperacion();
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(productoOperacion.Listar());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Create(Producto producto)
        {
            if (ModelState.IsValid)
            {
                productoOperacion.Agregar(producto);
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var producto = productoOperacion.ObtienePorId(id);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }

        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Edit(Producto producto)
        {
            if (ModelState.IsValid)
            {
                productoOperacion.Actualiza(producto);
                return RedirectToAction(nameof(Index));
            }
            return View(producto);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var producto = productoOperacion.ObtienePorId(id);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }

        [HttpPost, ActionName("Delete")]
        [AutoValidateAntiforgeryToken]
        public IActionResult DeleteProducto(int id)
        {
            var producto = productoOperacion.ObtienePorId(id);
            if (producto == null)
            {
                return NotFound();
            }
            productoOperacion.Elimina(producto);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
