﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestQC.Datos
{
    public interface IOperacion<T> where T:class
    {
        T ObtienePorId(int id);
        IEnumerable<T> Listar();
        void Agregar(T entity);
        void Actualiza(T entity);
        void Elimina(T entity);
    }
}
