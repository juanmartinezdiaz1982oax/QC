﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestQC.Business;
using TestQC.Models;

namespace TestQC.Datos
{
    public class ProductoOperacion : IOperacion<Producto>
    {
        public void Actualiza(Producto entity)
        {
            ListaProductos.Instance.Actualiza(entity);
        }

        public void Agregar(Producto entity)
        {
            ListaProductos.Instance.Agregar(entity);
        }

        public void Elimina(Producto entity)
        {
            ListaProductos.Instance.Elimina(entity.Id);
        }

        public IEnumerable<Producto> Listar()
        {
            return ListaProductos.Instance.Listar();
        }

        public Producto ObtienePorId(int id)
        {
            return ListaProductos.Instance.ObtienePorId(id);
        }
    }
}
